
package hospital_management_system;
  //june update
public class hospitalProject extends Variables {
	
	

	public static void main(String[] args) {
		
		getMap().put("kiruba", 300);
		getMap().put("manoj", 800);
		getMap().put("rafi", 200);
		getMap().put("vignesh", 150);
		getMap().put("ranjith", 110);

		MainFunction.profileSelectpage();
	}
}
