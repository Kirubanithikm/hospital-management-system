package hospital_management_system;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;


interface Sayable{  
    void say();  
}  

   

public class BlockCheck {

	
	int BlockNumber;
	String blockName;
 	int blockSeats;

	public BlockCheck(int BlockNumber, String blockName, int blockSeats) {
		this.BlockNumber = BlockNumber;
		this.blockName = blockName;
		this.blockSeats = blockSeats;
	}

	 public void saySomething(){  
	        System.out.println("Hello, this is non-static method.");  
	  
	 
	 
	 BlockCheck methodReference = new BlockCheck(BlockNumber, blockName, blockSeats); // Creating object  
       
           Sayable sayable = methodReference::saySomething;  
      
           sayable.say();  
	  }  
	static void blockCheckMethod() {
	
	
	System.out.println("Surgical block");
	System.out.println("Emergency block");
	System.out.println("Accident block");
	System.out.println("Nerve block");
	System.out.println("Heart block");
	
	Scanner blockFindScanner= new Scanner(System.in);
	
	System.out.println("Enter the block name");
	String blockNameString = blockFindScanner.next();

	List<BlockCheck> productsList = new ArrayList<BlockCheck>();
	
	productsList.add(new BlockCheck(1, "Surgical", 250));
	productsList.add(new BlockCheck(2, "Emergency", 300));
	productsList.add(new BlockCheck(3, "Accident", 280));
	productsList.add(new BlockCheck(4, "Nerve", 180));
	productsList.add(new BlockCheck(5, "Heart", 90));
	Map<Integer, Integer> productPriceList = productsList.stream()
			
			.filter(p -> p.blockName.equals(blockNameString))
			//.map(p -> p.blockSeats, p -> p.blockName)
			//.map(p -> p.blockName, )
			.collect(Collectors.toMap(p -> p.BlockNumber, p -> p.blockSeats));
	System.out.println("Block number and the available seats are"+productPriceList);

	
	
	
	}
	
	
	
	
	
}
