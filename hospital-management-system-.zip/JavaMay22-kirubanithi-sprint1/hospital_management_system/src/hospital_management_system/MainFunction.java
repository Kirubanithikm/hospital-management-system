package hospital_management_system;

import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Date;

interface AdminNameString{  
    public String say(String adminname);
    
}  

public class MainFunction extends Variables {

	static void profileSelectpage() {
		
		String adminNameString = "kiruba";
		String welcomeMessage = "Welcome";
		AdminNameString s1=(adminname)->{  
            return "Hii,"+adminname;  
        };  
        
   
        System.out.println(s1.say(welcomeMessage  + " to Trichy hospital")); 
		try {
			
			DateFormat dateandtimeformater = new SimpleDateFormat("dd/MM/yyyy hh.mm aa");
			String dateString = dateandtimeformater.format(new Date()).toString();
			System.out.println("Date and time is: " + dateString);
			System.out.println("Please select your profile :");
			System.out.println("1.Admin -- 2.User -- 3.Close");
			Scanner scanner = new Scanner(System.in);

			setProfileselect(scanner.nextInt());
			switch (getProfileselect()) {
			case 1:

				Scanner inputScanneradmin = new Scanner(System.in);
				System.out.println("Please enter username");
				setCheckuname(inputScanneradmin.next());
				System.out.println("Please enter password");
				setCheckpw(inputScanneradmin.nextInt());

				if (getCheckuname().equals(adminNameString) && getCheckpw() == 1234) {

					HospitalAdmin.admin();
				} else {
					System.out.println("You are enter wrong username and password");
					MainFunction.profileSelectpage();
				}
			case 2:
				HospitalUser.user();
			case 3:
				System.exit(0);
			default:
				System.out.println("Please select correct profile ");
				System.out.println("---------------------------------");
			}
		} catch (Exception e) {
			System.out.println("You are enter wrong key");
			System.out.println("---------------------------------");
		} finally {
			MainFunction.profileSelectpage();
		}
	}
}
