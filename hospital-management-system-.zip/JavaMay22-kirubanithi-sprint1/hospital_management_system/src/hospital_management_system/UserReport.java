package hospital_management_system;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

class CustomException extends Exception {
	public CustomException(String message) {
		// call the constructor of Exception class
		super(message);
	}
}

public class UserReport extends Variables implements Runnable {

	public void run() {
		System.out.println("Thread is running..... ");

	}

	public UserReport(String name, int wrongamount, int correctamount, String message) {

		super();
		this.wrongamount = wrongamount;
		this.correctamount = correctamount;
		this.name = name;
		this.message = message;
	}

	static void userReport() {
		Scanner usermessageScanner = new Scanner(System.in);
		System.out.print("Enter your name");
		String name = usermessageScanner.next();
		System.out.print("Enter your wrong amount");
		int wrongamount = usermessageScanner.nextInt();
		System.out.print("Enter your correct amount");
		int correctamount = usermessageScanner.nextInt();
		Scanner usermessagetextScanner = new Scanner(System.in);
		System.out.print("enter your report message");
		String message = usermessagetextScanner.nextLine();
		UserReport mymessage = new UserReport(name, wrongamount, correctamount, message);

		getList().add(mymessage);
		HospitalUser.user();

	}

	synchronized static void adminReportView() {

		boolean checkreview = getList().isEmpty();
		if (checkreview == true) {

			System.out.println("No reviews added");
		} else {
			System.out.println("Reviews :");
			for (UserReport b : getList()) {
				System.out.println("Hiii I am " + b.getName() + "." + "My bill amount was enterd" + " "
						+ b.getWrongamount() + "." + "But my actual bill amount is " + b.getCorrectamount() + " ");
				// System.out.println("User report review :" + b.message);
				System.out.printf("%-15s: %s%n", "User report review", b.getMessage());

				try {
					System.out.println("----Take 5 seconds and read the user review carefully--- ");
					Thread.sleep(5000);
				} catch (Exception e) {
					System.out.println(e);
				}
			}
		}
		HospitalAdmin.admin();

	}

	static void invidualPtReview() throws CustomException {
		// throw exception if language already present in ArrayList
		System.out.println("Enter your reporting patient name");
		Scanner invidualPtName = new Scanner(System.in);
		String nameptetString = invidualPtName.next();

		if (getName().contains(nameptetString)) {
			System.out.println(nameptetString + " is written the report or review");

			for (UserReport b : getList()) {
				System.out.println("Your selected patient name is :  " + b.getName());
				// System.out.println("User report review :" + b.message);
				System.out.printf("%-15s: %s%n", "your selected patient review is : ", b.getMessage());
			}
			HospitalAdmin.admin();
		} else {
			System.out.println(nameptetString + "is your selected patient name");
			throw new CustomException("Your selected patient " + nameptetString + " is not there");
		}

	}

	static void adminReportEdit() {

		try {
			invidualPtReview();

		} catch (CustomException e) {
			System.out.println("[" + e + "] Exception is Occured in patient review page");
		}
	}

}
