package hospital_management_system;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.Collectors;

public class HospitalProjectMethods extends Variables {

	static void updatePatient() {
		System.out.println("Update patient data");
		Scanner sc3 = new Scanner(System.in);
		System.out.println("Enter patient name");
		setUtptname(sc3.next());
		System.out.println("Enter patient bill amount");
		setUtptamount(sc3.nextInt());
		// sc3.close();
		getMap().replace(getUtptname(), getUtptamount());

		HospitalAdmin.admin();
	}

	static void addPatient() {

		System.out.println("Patient add page");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number of patient you want to add : ");

		setNumptadd(sc.nextInt());

		for (int i = 0; i < getNumptadd(); i++) {
			System.out.println("Enter patient name");
			setPtname(sc.next());
			System.out.println("Enter the patient bill amount");
			setPtamount(sc.nextInt());

			getMap().put(getPtname(), getPtamount());
		}
		HospitalAdmin.admin();

		
	}
	
	
	
	static void filterPatient() {
		
		
		
		
		
		        

	}
	

	static void shifDoctors() {
		System.out.println("Monring shift doctors");

		getShiftOneDoctors().add("Dr.Harishkumar");
		getShiftOneDoctors().add("Dr.Dhinesh");
		getShiftOneDoctors().add("Dr.Prasanth");
		getShiftOneDoctors().add("Dr.Ramkumar");
		getShiftOneDoctors().add("Dr.Ajay");
		System.out.println(getShiftOneDoctors());

		System.out.println("night shift doctors");

		getShiftTwoDoctors().add("Dr.Maran");
		getShiftTwoDoctors().add("Dr.Abishek");
		getShiftTwoDoctors().add("Dr.Deepak");
		getShiftTwoDoctors().add("Dr.Karthik");
		getShiftTwoDoctors().add("Dr.RameshKumar");
		System.out.println(getShiftTwoDoctors());

		System.out.println("Are you want to show all Doctors list");
		System.out.println("If yes Please enter y or enter n");

		Scanner totalDocAdd = new Scanner(System.in);

		String totalDoctors = totalDocAdd.next();

		if (totalDoctors.equals("y") || totalDoctors.equals("Y")) {
			getShiftOneDoctors().addAll(getShiftTwoDoctors());
			System.out.println(getShiftOneDoctors());

		} else {
			HospitalAdmin.admin();
		}
		HospitalAdmin.admin();

	}

	static void totalDoctors() {
//
//		getShiftOneDoctors().add("Dr.Harishkumar");
//		getShiftOneDoctors().add("Dr.Dhinesh");
//		getShiftOneDoctors().add("Dr.Prasanth");
//		getShiftOneDoctors().add("Dr.Ramkumar");
//		getShiftOneDoctors().add("Dr.Ajay");
//		
//		
//		getShiftTwoDoctors().add("Dr.Maran");
//		getShiftTwoDoctors().add("Dr.Abishek");
//		getShiftTwoDoctors().add("Dr.Deepak");
//		getShiftTwoDoctors().add("Dr.Karthik");
//		getShiftTwoDoctors().add("Dr.RameshKumar");

		getShiftOneDoctors().addAll(getShiftTwoDoctors());
		System.out.println(getShiftOneDoctors());

		HospitalAdmin.admin();
	}

	static void checkDoctorforUSerside() {

		String[] str = new String[10];
		System.out.println("Total blocks are 10");

		// str[0] = "Block 1 is available";
		str[1] = "Block 1 is available";
		str[2] = "Block 2 is available";
		str[3] = "Block 3 is available";

		Scanner checkBlockUSer = new Scanner(System.in);
		System.out.println("Enter Block number");
		Integer checkBlocks = checkBlockUSer.nextInt();

		Optional<String> checkNull = Optional.ofNullable(str[checkBlocks]);
		if (checkNull.isPresent()) {
			String lowercaseString = str[checkBlocks].toUpperCase();
			// int lowercaseString1=lowercaseString-1;
			System.out.print(lowercaseString + " today");
		} else
			System.out.println(checkBlocks + " Block is not available today");

		HospitalUser.user();

	}

	static void viewPatientforAdmin() {

		Boolean patientCheck = getMap().isEmpty();
		if (patientCheck == true) {
			System.out.println("No patients added");
		} else {
			System.out.println("View patient details");

			for (Map.Entry m : getMap().entrySet()) {
				System.out.println(m.getKey() + " " + m.getValue());
			}
		}
		HospitalAdmin.admin();
	}

	static void deletePatient() {
		System.out.println("Delete patient data");

		Scanner sc2 = new Scanner(System.in);
		setDelpt(sc2.next());
		// sc2.close();
		getMap().remove(getDelpt());

		HospitalAdmin.admin();
	}

	static void clearAllPatients() {
		System.out.println("Clear all patients");
		getMap().clear();
		HospitalAdmin.admin();
	}

	static void viewPatientforUser() {
		System.out.println("View patient details");
//		getMap().put("Kiruba", 300);
//		getMap().put("Manoj", 800);
//		getMap().put("Rafi", 200);
//		getMap().put("Vignesh", 150);
//		getMap().put("Ranjith", 110);
		System.out.println("Enter your name");
		Scanner sc4 = new Scanner(System.in);
		String searchkey = sc4.next();
		int usersearchvalue = getMap().get(searchkey);
		System.out.println("Your bill amount is" + usersearchvalue);

//		for (Map.Entry m : getMap().entrySet()) {
//			System.out.println(m.getKey() + " " + m.getValue());
//		}
		HospitalUser.user();
	}

}
