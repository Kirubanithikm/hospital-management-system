package hospital_management_system;

import java.util.Scanner;

public class HospitalUser {

	static void user() {
		
		System.out.println("");
		System.out.println("User page");
		Scanner inputScanneruser = new Scanner(System.in);

		System.out.println("Please enter the number :");
		System.out.println("1.View patients data\n2.Wrinte a review\n3.Switch to profile select page\n4.Exit \n5.checkDoctorforUSerside\n 6.filterPatient\n7.Block check");

		try {

			int mychoiceIntegeruser = inputScanneruser.nextInt();
			// inputScanneruser.close();

			switch (mychoiceIntegeruser) {

			case 1:
				HospitalProjectMethods.viewPatientforUser();
				break;
			case 2:
				UserReport.userReport();
				break;
			case 3:
				MainFunction.profileSelectpage();
				break;
			case 4:
				System.exit(0);
				break;
			case 5:
				HospitalProjectMethods.checkDoctorforUSerside();
				break;
			case 6:
				HospitalProjectMethods.filterPatient();
				break;
			case 7:
				BlockCheck.blockCheckMethod();
			default:
				System.out.println("Please select correct profile");
				System.out.println("---------------------------------");
			}
		} catch (Exception e) {
			System.out.println("You are entering wrong key");
			System.out.println("---------------------------------");
		} finally {
			MainFunction.profileSelectpage();

		}
	}
}
