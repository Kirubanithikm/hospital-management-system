package hospital_management_system;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class Variables {
	MainFunction mainFunction = new MainFunction();
	
	static String adminNameString= "manoj";
	protected static String name;
	protected int wrongamount;
	protected int correctamount;
	protected String message;
	private static int numptadd;
	private static String ptname;
	private static int ptamount;
	private static String delpt;
	private static int utptamount;
	private static String utptname;
	private static String report;
	private static String checkuname;
	private static String adminpw;
	private static int checkpw;
	private static int profileselect;
	private static HashMap<String, Integer> map = new HashMap<String, Integer>();
	private static List<UserReport> list = new LinkedList<UserReport>();
	private static Set<String> shiftOneDoctors = new LinkedHashSet<>();
	private static ArrayList<String> shiftTwoDoctors = new ArrayList<String>();
	
	public static Set<String> getShiftOneDoctors() {
		return shiftOneDoctors;
	}
	public static void setShiftOneDoctors(Set<String> shiftOneDoctors) {
		Variables.shiftOneDoctors = shiftOneDoctors;
	}
	public static ArrayList<String> getShiftTwoDoctors() {
		return shiftTwoDoctors;
	}
	public static void setShiftTwoDoctors(ArrayList<String> shiftTwoDoctors) {
		Variables.shiftTwoDoctors = shiftTwoDoctors;
	}
	public static String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getWrongamount() {
		return wrongamount;
	}
	public void setWrongamount(int wrongamount) {
		this.wrongamount = wrongamount;
	}
	public int getCorrectamount() {
		return correctamount;
	}
	public void setCorrectamount(int correctamount) {
		this.correctamount = correctamount;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public static int getNumptadd() {
		return numptadd;
	}
	public static void setNumptadd(int numptadd) {
		Variables.numptadd = numptadd;
	}
	public static String getPtname() {
		return ptname;
	}
	public static void setPtname(String ptname) {
		Variables.ptname = ptname;
	}
	public static int getPtamount() {
		return ptamount;
	}
	public static void setPtamount(int ptamount) {
		Variables.ptamount = ptamount;
	}
	public static String getDelpt() {
		return delpt;
	}
	public static void setDelpt(String delpt) {
		Variables.delpt = delpt;
	}
	public static int getUtptamount() {
		return utptamount;
	}
	public static void setUtptamount(int utptamount) {
		Variables.utptamount = utptamount;
	}
	public static String getUtptname() {
		return utptname;
	}
	public static void setUtptname(String utptname) {
		Variables.utptname = utptname;
	}
	public static String getReport() {
		return report;
	}
	public static void setReport(String report) {
		Variables.report = report;
	}
	public static String getCheckuname() {
		return checkuname;
	}
	public static void setCheckuname(String checkuname) {
		Variables.checkuname = checkuname;
	}
	public static String getAdminpw() {
		return adminpw;
	}
	public static void setAdminpw(String adminpw) {
		Variables.adminpw = adminpw;
	}
	public static int getCheckpw() {
		return checkpw;
	}
	public static void setCheckpw(int checkpw) {
		Variables.checkpw = checkpw;
	}
	public static int getProfileselect() {
		return profileselect;
	}
	public static void setProfileselect(int profileselect) {
		Variables.profileselect = profileselect;
	}
	public static HashMap<String, Integer> getMap() {
		return map;
	}
	public static void setMap(HashMap<String, Integer> map) {
		Variables.map = map;
	}
	public static List<UserReport> getList() {
		return list;
	}
	public static void setList(List<UserReport> list) {
		Variables.list = list;
	}
	

}
