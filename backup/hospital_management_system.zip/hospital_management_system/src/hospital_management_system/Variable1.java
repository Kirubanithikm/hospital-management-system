//package hospital_management_system;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.LinkedHashSet;
//import java.util.Set;
//
//public class Variable1 {
//
//	private  int numptadd;
//	private  String ptname;
//	private  int ptamount;
//	private  String delpt;
//	private  int utptamount;
//	private  String utptname;
//	private  String report;
//	private  String checkuname;
//	
//	
//	
//	public  int getNumptadd() {
//		return numptadd;
//	}
//	public  void setNumptadd(int numptadd) {
//		this.numptadd = numptadd;
//	}
//	public  String getPtname() {
//		return ptname;
//	}
//	public  void setPtname(String ptname) {
//		this.ptname = ptname;
//	}
//	public  int getPtamount() {
//		return ptamount;
//	}
//	public  void setPtamount(int ptamount) {
//		this.ptamount = ptamount;
//	}
//	public  String getDelpt() {
//		return delpt;
//	}
//	public  void setDelpt(String delpt) {
//		this.delpt = delpt;
//	}
//	public  int getUtptamount() {
//		return utptamount;
//	}
//	public  void setUtptamount(int utptamount) {
//		this.utptamount = utptamount;
//	}
//	public  String getUtptname() {
//		return utptname;
//	}
//	public  void setUtptname(String utptname) {
//		this.utptname = utptname;
//	}
//	public  String getReport() {
//		return report;
//	}
//	public  void setReport(String report) {
//		this.report = report;
//	}
//	public  String getCheckuname() {
//		return checkuname;
//	}
//	public  void setCheckuname(String checkuname) {
//		this.checkuname = checkuname;
//	}
//	
//	
//	
//	//-----------------------------//
//	
//	private  HashMap<String, Integer> map = new HashMap<String, Integer>();
//	//private static List<UserReport> list = new LinkedList<UserReport>();
//	private static Set<String> shiftOneDoctors = new LinkedHashSet<>();
//	private static ArrayList<String> shiftTwoDoctors = new ArrayList<String>();
//	
//	public  Set<String> getShiftOneDoctors() {
//		return shiftOneDoctors;
//	}
//	public  void setShiftOneDoctors(Set<String> shiftOneDoctors) {
//		this.shiftOneDoctors = shiftOneDoctors;
//	}
//	public static ArrayList<String> getShiftTwoDoctors() {
//		return shiftTwoDoctors;
//	}
//	public  void setShiftTwoDoctors(ArrayList<String> shiftTwoDoctors) {
//		this.shiftTwoDoctors = shiftTwoDoctors;
//	}
//	
//	public  HashMap<String, Integer> getMap() {
//		return map;
//	}
//	public  void setMap(HashMap<String, Integer> map) {
//		this.map = map;
//	}
//	
//	
//	
//	
//	
//}
