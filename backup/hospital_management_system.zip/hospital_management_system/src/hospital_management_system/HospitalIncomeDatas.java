package hospital_management_system;

import java.io.*;
import java.util.Scanner;

public class HospitalIncomeDatas implements java.io.Serializable{

	static String filename = "file.ser";
	public Integer year;
	public Integer income;
	public String notes;

	public HospitalIncomeDatas(Integer year, Integer income, String notes) {
		this.year = year;
		this.income = income;
		this.notes = notes;
	}

	static void writeIncomeReport() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the year for fill the Income datas");
		Integer year = scanner.nextInt();
		System.out.println("Enter the Income amount");
		Integer income = scanner.nextInt();
		System.out.println("Enter the notes for your future reference");
		String notes = scanner.next();

		HospitalIncomeDatas object = new HospitalIncomeDatas(year, income, notes);

		try {
			FileOutputStream file = new FileOutputStream(filename);
			ObjectOutputStream out = new ObjectOutputStream(file);

			out.writeObject(object);

			out.close();
			file.close();
			System.out.println("Entered datas are stroed in Serialized format");
		} catch (IOException ex) {
			System.out.println("IOException is caught in Income datas stored side");
		}
	}

	static void readIncomeReport() {

		HospitalIncomeDatas object1 = null;
		try {

			FileInputStream file = new FileInputStream(filename);
			ObjectInputStream in = new ObjectInputStream(file);

			object1 = (HospitalIncomeDatas) in.readObject();

			in.close();
			file.close();

			System.out.println("Entered datas are Deserialized  and the datas are :");
			System.out.println("Year is : = " + object1.year);
			System.out.println("Income of "+object1.year +" is : = " + object1.income);
			System.out.println("Notes of "+object1.year +" is : = " + object1.notes);
		}

		catch (IOException ex) {
			System.out.println("IOException is caught");
		} catch (ClassNotFoundException ex) {
			System.out.println("ClassNotFoundException is caught");
		}
	}

}
