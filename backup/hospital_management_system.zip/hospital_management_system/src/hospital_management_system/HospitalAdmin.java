package hospital_management_system;

import java.util.Scanner;

public class HospitalAdmin {

	static void admin() {
		Scanner inputScanneradmin1 = new Scanner(System.in);

		System.out.println("Please select what you do :");
		System.out.println(
				"1.add patient\n2.update patient\n3.delete patient\n4.view patients data\n5.view user review\n6.Delete all patients\n7.ambulance check\n8.Doctors list\n9.Total doctors\n10.admin review check"
				+ "\n11.Write income report\n12.Read income report\n13.Go to the profile select page\n14.Exit"
						 );
		try {

			int mychoiceIntegeradmin = inputScanneradmin1.nextInt();

			switch (mychoiceIntegeradmin) {

			case 1:
				HospitalProjectMethods.addPatient();
				break;
			case 2:
				HospitalProjectMethods.updatePatient();
				break;

			case 3:
				HospitalProjectMethods.deletePatient();
				break;

			case 4:
				HospitalProjectMethods.viewPatientforAdmin();
				break;
			case 5:
				UserReport.adminReportView();
				break;
			case 6:
				HospitalProjectMethods.clearAllPatients();
				break;
			case 7:
				AmbulanceCheck objAmbulanceCheck = new AmbulanceCheck();
				objAmbulanceCheck.main();
				break;
			case 8:
				HospitalProjectMethods.shifDoctors();
				break;
			case 9:
				HospitalProjectMethods.totalDoctors();
				break;
			case 10:
				UserReport.adminReportEdit();
				break;
			case 11:
				HospitalIncomeDatas.writeIncomeReport();
				break;
			case 12:
				HospitalIncomeDatas.readIncomeReport();
				break;
			case 13:
				MainFunction.profileSelectpage();
				break;
			case 14:
				System.exit(0);
				break;

			default:
				System.out.println("Please select correct profile");
				System.out.println("---------------------------------");

			}
		} catch (Exception e) {
			System.out.println("You are entering wrong key");
			System.out.println("---------------------------------");
		} finally {
			MainFunction.profileSelectpage();
		}

	}

}
