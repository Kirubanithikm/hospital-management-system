package hospital_management_system;

import java.util.Scanner;



interface pageWelcomeMsg {
	void say(String msg); 
	
}


public class AmbulanceCheck extends HospitalAdmin implements pageWelcomeMsg {



		public void say(String msg) {
			System.out.println(msg);
			
		}
		public static void print() {
			AmbulanceCheck fie = new AmbulanceCheck();
			fie.say("This is ambulance check page");
	}

	Integer ambulance(Integer basicLifeSupportAm) {

		Integer availablebasicLifeSupportAm = 50;
		
		Integer total= availablebasicLifeSupportAm - basicLifeSupportAm;
		System.out.println("Remaing mobile icu are:"+total);
		HospitalAdmin.admin();
		return 0;
	}

	Integer ambulance(String admin, Integer icuAmbulance) {
		Integer availabileIcuam = 20;
		
		Integer total2= availabileIcuam - icuAmbulance;
		System.out.println(admin + " " + "Remainings mobile icu are"+total2);
		HospitalAdmin.admin();
		return 0;
	}
	
	
	
     public void main() {
    	 print();
    	 
	System.out.println("Select 1.Basic life support ambulance 2.Mobile ICU support ambulance");

	Scanner scanner = new Scanner(System.in);
	Integer selectvalue = scanner.nextInt();
	switch(selectvalue){
	
		case 1:
			System.out.println("Available basic ambulance are 50");
			System.out.println("How many basic ambulance you need:");
			Integer basicLifeSupportAm = scanner.nextInt();
			System.out.println(ambulance(basicLifeSupportAm));
			break;
		
		case 2:
			System.out.println("Available icu ambulance are 20");
			System.out.println("Enter how many icu ambulance you need");
			Integer icuAmbulance = scanner.nextInt();
			System.out.println(ambulance("Hello admin", icuAmbulance));
			
			break;
	   default:
		   System.out.println("You are enter wrong key");
		   HospitalAdmin.admin();
	
	}
}     
}

     











