package hospital_management_system;

import java.util.LinkedList;
import java.util.List;

public class UserReportVariables {
	
	protected int wrongamount;
	protected int correctamount;
	protected String message;
	protected static String name;
	private static List<UserReport> list = new LinkedList<UserReport>();
	
	public static String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public int getWrongamount() {
		return wrongamount;
	}
	public void setWrongamount(int wrongamount) {
		this.wrongamount = wrongamount;
	}
	public int getCorrectamount() {
		return correctamount;
	}
	public void setCorrectamount(int correctamount) {
		this.correctamount = correctamount;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public static List<UserReport> getList() {
		return list;
	}
	public  void setList(List<UserReport> list) {
		this.list = list;
	}
	
	

}
